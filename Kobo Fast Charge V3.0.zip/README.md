![Banner](https://github.com/user-attachments/assets/f6586643-4ce9-486c-adbe-835017bfaefd)

Kobo GSI Fast Charge

Q: How does it work? <br />
YMD: Modify the battery temperature file to 38 celcius
